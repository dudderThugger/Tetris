package tetris;

import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Szelestey Adam
 * @see GameForm class, the frame of the game
 */
public class GameForm extends JFrame {
    /**
     * Reference of the menu panel
     */
    private Menu menu;
    /**
     * Reference of the game panel
     */
    private Game game;
    /**
     * Reference of the leaderboard panel
     */
    private LeaderBoard leaderBoard;

    /**
     * Constructor, calls the init method
     */
    public GameForm() {
        this.initComponents();
    }

    /**
     * Sets the frame and initializes the three main panels of the game
     */
    private void initComponents() {
        this.menu = new Menu(this);
        this.leaderBoard = new LeaderBoard(this);
        this.game = new Game(this);
        this.setDefaultCloseOperation(3);
        this.setSize(500, 700);
        this.setLayout((LayoutManager)null);
        this.setResizable(false);
        this.setTitle("Tetris");
        this.getContentPane().add(this.menu);
        this.getContentPane().add(this.game);
        this.getContentPane().add(this.leaderBoard);
        this.setLocationRelativeTo((Component)null);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                GameForm.this.game.saveOnExit();
                e.getWindow().dispose();
            }});
        this.startMenu();
    }

    /**
     * Shows the menu and hides other panels
     */
    public void startMenu() {
        this.game.setVisible(false);
        this.leaderBoard.setVisible(false);
        this.menu.setVisible(true);
    }

    /**
     * Shows the game panel and hides other panels
     */
    public void game() {
        this.game.requestName();
        this.menu.setVisible(false);
        this.leaderBoard.setVisible(false);
        this.game.setVisible(true);
        this.game.requestFocusInWindow();
    }

    /**
     * Shows the leaderboard and hides other panels
     */
    public void leaderBoard() {
        this.menu.setVisible(false);
        this.game.setVisible(false);
        this.leaderBoard.setVisible(true);
    }

    /**
     * Shows the menu and calls the leaderboard's gameEnd method
     */
    public void gameEnd() {
        this.game.setVisible(false);
        this.menu.setVisible(true);
        this.leaderBoard.setVisible(false);
        this.leaderBoard.gameEnd();
    }

    /**
     * The main method of the application, makes a new frame and sets it visible
     * @param args
     */
    public static void main(String[] args) {
        GameForm game = new GameForm();
        game.setVisible(true);
    }

    /**
     * @return the leaderboard
     */
    public LeaderBoard getLeaderBoard() {
        return this.leaderBoard;
    }

    /**
     * If the save/game.txt files contains a savable game's serialization loads the game from that state,
     * in other cases nothing happens
     */
    public void continueGame() {
        try {
            if ((new File("save/game.txt")).exists()) {
                FileInputStream file = new FileInputStream("save" + File.separator + "game.txt");
                ObjectInputStream in = new ObjectInputStream(file);
                this.game.continueGame((SavableGame)in.readObject());
                in.close();
            }
        } catch (IOException var3) {
            var3.printStackTrace();
        } catch (ClassNotFoundException var4) {
            var4.printStackTrace();
        }

        this.game.setVisible(true);
        this.menu.setVisible(false);
        this.leaderBoard.setVisible(false);
        this.game.requestFocusInWindow();
    }
}
