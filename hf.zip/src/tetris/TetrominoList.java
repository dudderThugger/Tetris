package tetris;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * @author Szelestey Adam
 * @see TetrominoList class, responsible for the storagement of the tetrominos
 */
public class TetrominoList implements Serializable {
    /**
     * The list of the different tetromino's
     */
    ArrayList<Tetromino> all = new ArrayList();

    /**
     * Adds an element to the tetromino's list
     * @param t the element to be added
     */
    public void add(Tetromino t) {
        this.all.add(t);
    }

    /**
     * @return A random tetromino from the list
     */
    public Tetromino getTetromino() {
        Random random = new Random();
        int upperBound = this.all.size();
        int retIdx = random.nextInt(upperBound);
        return (Tetromino)this.all.get(retIdx);
    }

    /**
     * Adds the basic tetrominos of the Tetris game
     */
    public void addBasicShapes() {
        this.add(new Tetromino(new int[][]{{1}, {1}, {1}, {1}}, new Color(0, 255, 255), "I"));
        this.add(new Tetromino(new int[][]{{1, 0}, {1, 0}, {1, 1}}, new Color(255, 127, 0), "L"));
        this.add(new Tetromino(new int[][]{{1, 1}, {1, 1}}, new Color(255, 255, 0), "O"));
        this.add(new Tetromino(new int[][]{{0, 1}, {0, 1}, {1, 1}}, new Color(0, 0, 255), "J"));
        this.add(new Tetromino(new int[][]{{0, 1, 1}, {1, 1, 0}}, new Color(0, 255, 0), "Z"));
        this.add(new Tetromino(new int[][]{{0, 1, 0}, {1, 1, 1}}, new Color(128, 0, 128), "T"));
        this.add(new Tetromino(new int[][]{{1, 1, 0}, {0, 1, 1}}, new Color(255, 0, 0), "S"));
    }
}